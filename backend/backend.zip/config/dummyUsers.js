// Local Development Dummy Users
// ONLY for localhost - NOT used in production

const DUMMY_USERS = [
  // Client
  {
    email: 'client@test.com',
    password: 'test123',
    role: 'client',
    name: 'Test Client',
    poolType: 'client'
  },
  
  // Relationship Manager
  {
    email: 'rm@test.com',
    password: 'test123',
    role: 'rm',
    name: 'Test RM',
    poolType: 'internal'
  },
  
  // Branch Manager
  {
    email: 'bm@test.com',
    password: 'test123',
    role: 'branch_manager',
    name: 'Test Branch Manager',
    poolType: 'internal'
  },
  
  // Zonal Head
  {
    email: 'zh@test.com',
    password: 'test123',
    role: 'zonal_head',
    name: 'Test Zonal Head',
    poolType: 'internal'
  },
  
  // Director
  {
    email: 'director@test.com',
    password: 'test123',
    role: 'director',
    name: 'Test Director',
    poolType: 'internal'
  },
  
  // Super Admin
  {
    email: 'admin@test.com',
    password: 'test123',
    role: 'super_admin',
    name: 'Test Admin',
    poolType: 'internal'
  }
];

// Helper to find user
export function findDummyUser(email, password) {
  return DUMMY_USERS.find(
    (u) => u.email === email && u.password === password
  );
}

export { DUMMY_USERS };
