// Database configuration
const dbConfig = {
  // Add your database configuration here
  // Example for MongoDB:
  // mongoURI: process.env.MONGO_URI || 'mongodb://localhost:27017/yourdb'
  
  // Example for MySQL/PostgreSQL:
  // host: process.env.DB_HOST || 'localhost',
  // port: process.env.DB_PORT || 5432,
  // database: process.env.DB_NAME || 'yourdb',
  // user: process.env.DB_USER || 'root',
  // password: process.env.DB_PASSWORD || ''
};

module.exports = dbConfig;
